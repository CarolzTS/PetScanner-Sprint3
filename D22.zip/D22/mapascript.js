var map = L.map('map').setView([-19.932792, -43.936054], 13);
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap'
}).addTo(map);
var marker = L.marker([-19.932818, -43.937468]).addTo(map);
var circle = L.circle([-19.936217, -43.938155], {
  color: 'red',
  fillColor: '#f03',
  fillOpacity: 0.5,
  radius: 200
}).addTo(map);
var polygon = L.polygon([
[-19.932792, -43.936054]
]).addTo(map);
marker.bindPopup("<b>Gato reportado como sumido!</b><br>Procure nesta região pelo Omen.").openPopup();
circle.bindPopup("Área comum de gatos se perderem, gatos perdidos na área no mês: 12.");
polygon.bindPopup("Você está aqui.");
var popup = L.popup()
    .setLatLng([-19.933386571250786, -43.93362272739513])
    .setContent("Cachorro Lucky perdido nesta área.")
    .openOn(map);
    function onMapClick(e) {
      alert("Procurar por pets nesta região" + e.latlng);
  }
  
  map.on('click', onMapClick);
  var popup = L.popup();

  function onMapClick(e) {
      popup
          .setLatLng(e.latlng)
          .setContent("Realizar scan de pets aqui? " + e.latlng.toString())
          .openOn(map);
  }
  
  map.on('click', onMapClick);
